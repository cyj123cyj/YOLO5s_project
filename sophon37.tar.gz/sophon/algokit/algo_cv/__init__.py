"""the implementation of computer vision algorithm
"""
