"""the implementation of computer vision detection algorithm

Detection type:
    Object detection
    Face detection
    Pedestrian detection
"""
