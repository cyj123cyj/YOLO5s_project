"""The Dependent libraries of sailalgokit
"""
