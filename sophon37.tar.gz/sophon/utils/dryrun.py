if __name__ == '__main__':
  import sys
  import sophon.sail as sail
  sail._dryrun(sys.argv[1])
